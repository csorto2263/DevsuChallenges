package com.example.devsue2echallenge;

import org.openqa.selenium.By;

public class Locators {
    // Localizadores de la página de inicio
    public static final By ProductLink(String productName) {
        return By.linkText(productName);
    }
    public static final By AddToCartLink() {
        return By.linkText("Add to cart");
    }
    public static final By ViewCart() {
        return By.id("cartur");
    }

    public static final By SUCCESS_BUTTON = By.className("btn-success");
    public static final By NAME_INPUT = By.id("name");
    public static final By COUNTRY_INPUT = By.id("country");
    public static final By CITY_INPUT = By.id("city");
    public static final By CARD_NUMBER_INPUT = By.id("card");
    public static final By MONTH_INPUT = By.id("month");
    public static final By YEAR_INPUT = By.id("year");
    public static final By PURCHASE_BUTTON = By.xpath("/html/body/div[3]/div/div/div[3]/button[2]");


}
