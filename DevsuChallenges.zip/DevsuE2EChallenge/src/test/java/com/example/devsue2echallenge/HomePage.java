package com.example.devsue2echallenge;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
    private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://www.demoblaze.com/");
    }

    public void addProductToCart(String productName) {
        WebElement productLink = driver.findElement(Locators.ProductLink(productName));
        productLink.click();
        WebElement cartLink = driver.findElement(Locators.AddToCartLink());
        cartLink.click();
    }

    public void viewCart() {
        WebElement viewCart = driver.findElement(Locators.ViewCart());
        viewCart.click();
    }
}
