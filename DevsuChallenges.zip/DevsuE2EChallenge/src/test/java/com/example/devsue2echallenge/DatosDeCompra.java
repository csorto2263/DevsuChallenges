package com.example.devsue2echallenge;

public class DatosDeCompra {
    public static final String Producto1 = "Samsung galaxy s6";
    public static final String Producto2 = "Nokia lumia 1520";
    public static final String NombreCliente = "Nombre de Prueba";
    public static final String Pais = "País de Prueba";
    public static final String Ciudad = "Ciudad de Prueba";
    public static final String Tarjeta = "1234567890123456";
    public static final String Mes = "01";
    public static final String Anio = "2025";


}
