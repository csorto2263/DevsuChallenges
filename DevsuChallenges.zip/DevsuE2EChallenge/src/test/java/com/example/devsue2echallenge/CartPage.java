package com.example.devsue2echallenge;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CartPage {
    private WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public String getPurchaseMessage() {
        return driver.findElement(By.cssSelector(".sweet-alert > h2:nth-child(6)")).getText();
    }

    public void completePurchase(String name, String country, String city, String cardNumber, String month, String year) {
        WebElement btn = driver.findElement(Locators.SUCCESS_BUTTON);
        btn.click();
        WebElement txt = driver.findElement(Locators.NAME_INPUT);
        txt.sendKeys(name);
        txt = driver.findElement(Locators.COUNTRY_INPUT);
        txt.sendKeys(country);
        txt = driver.findElement(Locators.CITY_INPUT);
        txt.sendKeys(city);
        txt = driver.findElement(Locators.CARD_NUMBER_INPUT);
        txt.sendKeys(cardNumber);
        txt = driver.findElement(Locators.MONTH_INPUT);
        txt.sendKeys(month);
        txt = driver.findElement(Locators.YEAR_INPUT);
        txt.sendKeys(year);
        btn = driver.findElement(Locators.PURCHASE_BUTTON);
        btn.click();
    }
}
